class arterialNetwork:
  def __init__(self, head):
    self.head = head
